<?php

$conn = mysqli_connect('localhost','root','','insurance2') or die('connection failed');

?>